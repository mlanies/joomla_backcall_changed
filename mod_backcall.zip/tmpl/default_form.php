<?php

use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;

$accepted_mime_types = '';
if ($params->get('accepted_file_mimes', '') != '') {
    $accepted_mime_types = 'accept="' . $params->get('accepted_file_mimes', '') . '"';
}
$multiple = '';
$multiple_fileselect = (int)$params->get('multiple_fileselect', 0);
if ($multiple_fileselect) {
    $multiple = 'multiple="multiple"';
}
?>
<script src="<?php echo URI::root() . 'media/com_backcall/js/jquery.maskedinput.min.js' ?>"></script>
<div class="backcallMessgesForm">
    <form class="backallform" method="post" enctype="multipart/form-data">
        <div class="control-group-backcall">
            <div class="control-label-backcall">
                <label id="jform_client_name-lbl" for="jform_subject">
                    <?php echo Text::_('COM_BACKCALL_ENTER_NAME') ?>
                </label>
            </div>
            <div class="controls-backcall">
                <input type="text" required="true" class="backcalltext form-control valid form-control-success"
                       id="jform_client_name" name="jform[client_name]"/>
            </div>
        </div>
        <?php if ($params->get('enable_phone', 1) == 1) { ?>
            <div class="control-group-backcall">
                <div class="control-label-backcall">
                    <label id="jform_phone-lbl" for="jform_phone">
                        <?php echo Text::_('COM_BACKCALL_ENTER_PHONE') ?>
                    </label>
                </div>
                <div class="controls-backcall">
                    <input type="text" required="true" class="backcalltext form-control valid form-control-success"
                           id="jform_phone" name="jform[phone]"/>
                </div>
            </div>
            <script>
                jQuery(function ($) {
                    jQuery("#jform_phone").mask("<?php echo $params->get('phone_mask') ?>");
                });
            </script>
        <?php } ?>
        <?php if ($params->get('enable_email', 1) == 1) { ?>
            <div class="control-group-backcall">
                <div class="control-label-backcall">
                    <label id="jform_email-lbl" for="jform_email">
                        <?php echo Text::_('COM_BACKCALL_ENTER_EMAIL') ?>
                    </label>
                </div>
                <div class="controls-backcall">
                    <input type="text" required="true" class="backcalltext form-control valid form-control-success"
                           id="jform_email" name="jform[email]"/>
                </div>
            </div>
        <?php } ?>
        <div class="control-group-backcall">
            <div class="control-label-backcall">
                <label id="jform_body-lbl" for="jform_body">
                    <?php echo Text::_('COM_BACKCALL_ENTER_BODY') ?>
                </label>
            </div>
            <div class="controls-backcall">
                <textarea required="true" class="backcalltext form-control valid form-control-success" id="jform_body"
                          name="jform[body]"></textarea>
            </div>
        </div>
        <?php if ($params->get('enable_file', 0) == 1) { ?>
            <div class="control-group-backcall">
                <div class="control-label-backcall">
                    <label id="jform_files-lbl" for="jform_files">
                        <?php echo Text::_('COM_BACKCALL_ENTER_FILES') ?>
                    </label>
                </div>
                <div class="controls-backcall">
                    <input <?php echo $multiple ?> type="file" class="backcalltext form-control valid form-control-success"
                           id="jform_files" <?php echo $accepted_mime_types ?> name="files[]"/>
                </div>
            </div>
        <?php } ?>
        <button type="submit" class="btn btn-success">
            <?php echo Text::_('COM_BACKCALL_SUBMIT'); ?>
        </button>
        <input type="hidden" name="module_id" value="<?php echo $module->id; ?>">
        <input type="hidden" name="backcall_action" value="sendsend">
        <input type="hidden" name="option" value="com_backcall">
        <input type="hidden" name="task" value="call.send">
        <input type="hidden" name="returl" value="<?php echo $url ?>">
    </form>
</div>