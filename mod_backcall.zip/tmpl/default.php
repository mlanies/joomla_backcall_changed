<?php

/**
 * @package     Joomla.Site
 * @subpackage  mod_backcall
 *
 * @copyright   (C) 2006 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Helper\ModuleHelper;

if ($params->get('moduletype', 0) == 0) {
    require ModuleHelper::getLayoutPath('mod_backcall', 'default_call');
} else {
    require ModuleHelper::getLayoutPath('mod_backcall', 'default_form');
}
?>

