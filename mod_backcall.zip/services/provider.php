<?php

/**
 * @package     Joomla.Site
 * @subpackage  mod_backcall
 *
 * @copyright   sitogon.ru
 * @license     GNU General Public License version 2 or later;
 */

\defined('_JEXEC') or die;

use Joomla\CMS\Extension\Service\Provider\HelperFactory;
use Joomla\CMS\Extension\Service\Provider\Module;
use Joomla\CMS\Extension\Service\Provider\ModuleDispatcherFactory;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;

/**
 * Модуль обратного звонка. <br>
Разработка   <a href=https://sitogon.ru/>www.sitogon.ru</a>
 *
 * @since  4.4.0
 */
return new class () implements ServiceProviderInterface {
    /**
     * Registers the service provider with a DI container.
     *
     * @param   Container  $container  The DI container.
     *
     * @return  void
     *
     * @since   4.4.0
     */
    public function register(Container $container): void
    {
        $container->registerServiceProvider(new ModuleDispatcherFactory('\\Joomla\\Module\\Backcall'));
        $container->registerServiceProvider(new HelperFactory('\\Joomla\\Module\\Backcall\\Site\\Helper'));

        $container->registerServiceProvider(new Module());
    }
};
