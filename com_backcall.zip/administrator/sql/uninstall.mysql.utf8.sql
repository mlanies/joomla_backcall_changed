DROP TABLE IF EXISTS `#__backcall_calls`;
DROP TABLE IF EXISTS `#__backcall_telegrams`;
DROP TABLE IF EXISTS `#__backcall_messages`;
