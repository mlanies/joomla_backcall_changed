CREATE TABLE IF NOT EXISTS `#__backcall_calls` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
`state` TINYINT(1)  NULL  DEFAULT 1,
`ordering` INT(11)  NULL  DEFAULT 0,
`checked_out` INT(11)  UNSIGNED,
`checked_out_time` DATETIME NULL  DEFAULT NULL ,
`created_by` INT(11)  NULL  DEFAULT 0,
`modified_by` INT(11)  NULL  DEFAULT 0,
`phone` VARCHAR(20)  NULL  DEFAULT "",
`client_name` TEXT NULL ,
`created` DATETIME DEFAULT NULL,
PRIMARY KEY (`id`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__backcall_messages` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
`state` TINYINT(1)  NULL  DEFAULT 1,
`ordering` INT(11)  NULL  DEFAULT 0,
`checked_out` INT(11)  UNSIGNED,
`checked_out_time` DATETIME NULL  DEFAULT NULL ,
`created_by` INT(11)  NULL  DEFAULT 0,
`modified_by` INT(11)  NULL  DEFAULT 0,
`email` TEXT  DEFAULT NULL,
`body` TEXT  DEFAULT NULL,
`subject` TEXT  DEFAULT NULL,
`files` TEXT DEFAULT NULL,
`phone` VARCHAR(20)  DEFAULT NULL,
`client_name` TEXT DEFAULT NULL ,
`created` DATETIME DEFAULT NULL ,
PRIMARY KEY (`id`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__backcall_telegrams` (
    `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `state` tinyint(1) DEFAULT 1,
    `ordering` int(11) DEFAULT 0,
    `checked_out` int(11) UNSIGNED DEFAULT NULL,
    `checked_out_time` datetime DEFAULT NULL,
    `created_by` int(11) DEFAULT 0,
    `modified_by` int(11) DEFAULT 0,
    `created` datetime DEFAULT NULL,
    `title` text DEFAULT NULL,
    `telegram_token` text DEFAULT NULL,
    `telegram_chatid` text DEFAULT NULL,
    PRIMARY KEY (`id`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__backcall_maxbots` (
    `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `state` tinyint(1) DEFAULT 1,
    `active` tinyint(1) DEFAULT 1,
    `ordering` int(11) DEFAULT 0,
    `checked_out` int(11) UNSIGNED DEFAULT NULL,
    `checked_out_time` datetime DEFAULT NULL,
    `created_by` int(11) DEFAULT 0,
    `modified_by` int(11) DEFAULT 0,
    `created` datetime DEFAULT NULL,
    `title` text DEFAULT NULL,
    `token` text DEFAULT NULL,
    `max_user_id` text DEFAULT NULL,
    `chat_id` text DEFAULT NULL,
    `secret_word` text DEFAULT NULL,
    `code` text DEFAULT NULL,
    PRIMARY KEY (`id`)
    ) DEFAULT COLLATE=utf8mb4_unicode_ci;


