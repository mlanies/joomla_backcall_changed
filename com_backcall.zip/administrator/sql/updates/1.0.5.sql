CREATE TABLE IF NOT EXISTS `#__backcall_maxbots` (
    `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `state` tinyint(1) DEFAULT 1,
    `active` tinyint(1) DEFAULT 1,
    `ordering` int(11) DEFAULT 0,
    `checked_out` int(11) UNSIGNED DEFAULT NULL,
    `checked_out_time` datetime DEFAULT NULL,
    `created_by` int(11) DEFAULT 0,
    `modified_by` int(11) DEFAULT 0,
    `created` datetime DEFAULT NULL,
    `title` text DEFAULT NULL,
    `token` text DEFAULT NULL,
    `max_user_id` text DEFAULT NULL,
    `chat_id` text DEFAULT NULL,
    `secret_word` text DEFAULT NULL,
    `code` text DEFAULT NULL,
    PRIMARY KEY (`id`)
    ) DEFAULT COLLATE=utf8mb4_unicode_ci;
