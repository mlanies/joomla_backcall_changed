<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Backcall
 * @author     Владимир <mail@sitogon.ru>
 * @copyright  2022 Владимир
 * @license    GNU General Public License версии 2 или более поздней; Смотрите LICENSE.txt
 */

namespace Backcall\Component\Backcall\Administrator\View\Messages;
// No direct access
defined('_JEXEC') or die;

use Backcall\Component\Backcall\Site\Helper\MainHelper;
use \Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use \Backcall\Component\Backcall\Administrator\Helper\BackcallHelper;
use \Joomla\CMS\Toolbar\Toolbar;
use \Joomla\CMS\Toolbar\ToolbarHelper;
use \Joomla\CMS\Language\Text;
use \Joomla\Component\Content\Administrator\Extension\ContentComponent;
use \Joomla\CMS\Form\Form;
use \Joomla\CMS\HTML\Helpers\Sidebar;
/**
 * View class for a list of Calls.
 *
 * @since  1.0.0
 */
class HtmlView extends BaseHtmlView
{
	protected $items;

	protected $pagination;

	protected $state;

	/**
	 * Display the view
	 *
	 * @param   string  $tpl  Template name
	 *
	 * @return void
	 *
	 * @throws Exception
	 */
	public function display($tpl = null)
	{
		$this->state = $this->get('State');
		$this->items = $this->get('Items');
		$this->pagination = $this->get('Pagination');
		$this->filterForm = $this->get('FilterForm');
		$this->activeFilters = $this->get('ActiveFilters');
        $MainHelper = new MainHelper();

        if (is_array($this->items)) {
            if (count($this->items)) {

                foreach ($this->items as $key=>$item) {
                    $html = '';
                    if ($MainHelper->isJson($item->files)) {
                        $files = json_decode($item->files);
                        foreach ($files as $file) {
                            $file = (array)$file;
                            $h = '<a target="_blank" href="'.\JUri::base().'index.php?option=com_backcall&task=messages.download&id='.$item->id.'&file='.$file['name'].'" class="btn btn-small btn-success downl"><i class="fa-solid fa-file-arrow-down"></i>'.$file['name'].'</a>';
                            $html .= $h;
                        }
                    }

                    $this->items[$key]->files = $html;

                }
            }
        }

		// Check for errors.
		if (count($errors = $this->get('Errors')))
		{
			throw new \Exception(implode("\n", $errors));
		}

		$this->addToolbar();

		$this->sidebar = Sidebar::render();
		parent::display($tpl);
	}

	/**
	 * Add the page title and toolbar.
	 *
	 * @return  void
	 *
	 * @since   1.0.0
	 */
	protected function addToolbar()
	{
		$state = $this->get('State');
		$canDo = BackcallHelper::getActions();

		ToolbarHelper::title(Text::_('COM_BACKCALL_MESSAGES'), "generic");

		$toolbar = Toolbar::getInstance('toolbar');

		// Check if the form exists before showing the add/edit buttons
		$formPath = JPATH_COMPONENT_ADMINISTRATOR . '/src/View/Calls';


        $toolbar->delete('messages.delete')
            ->text('JTOOLBAR_DELETE')
            ->message('JGLOBAL_CONFIRM_DELETE')
            ->listCheck(true);

		if ($canDo->get('core.admin'))
		{
			$toolbar->preferences('com_backcall');
		}

		// Set sidebar action
		Sidebar::setAction('index.php?option=com_backcall&view=messages');
	}
	
	/**
	 * Method to order fields 
	 *
	 * @return void 
	 */
	protected function getSortFields()
	{
		return array(
			'a.`id`' => Text::_('JGRID_HEADING_ID'),
			'a.`state`' => Text::_('JSTATUS'),
			'a.`ordering`' => Text::_('JGRID_HEADING_ORDERING'),
			'a.`phone`' => Text::_('COM_BACKCALL_CALLS_PHONE'),
			'a.`client_name`' => Text::_('COM_BACKCALL_CALLS_CLIENT_NAME'),
			'a.`created`' => Text::_('COM_BACKCALL_CALLS_CREATED'),
		);
	}

	/**
	 * Check if state is set
	 *
	 * @param   mixed  $state  State
	 *
	 * @return bool
	 */
	public function getState($state)
	{
		return isset($this->state->{$state}) ? $this->state->{$state} : false;
	}
}
