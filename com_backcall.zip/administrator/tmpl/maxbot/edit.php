<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Backcall
 * @author     Владимир <mail@sitogon.ru>
 * @copyright  2022 Владимир
 * @license    GNU General Public License версии 2 или более поздней; Смотрите LICENSE.txt
 */

// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\HTML\HTMLHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Uri\Uri;
use \Joomla\CMS\Router\Route;
use \Joomla\CMS\Language\Text;


HTMLHelper::addIncludePath(JPATH_COMPONENT . '/helpers/html');
$wa = $this->document->getWebAssetManager();
$wa->useScript('keepalive')
	->useScript('form.validate');
$v = filemtime(JPATH_ROOT . DIRECTORY_SEPARATOR . 'media/com_backcall/css/admin.css');
$wa->registerAndUseStyle('sitogonbackcallsadmincss', 'media/com_backcall/css/admin.css', ['version' => 'v=' . $v]);
HTMLHelper::_('bootstrap.tooltip');
?>

<form
	action="<?php echo Route::_('index.php?option=com_backcall&layout=edit&id=' . (int) $this->item->id); ?>"
	method="post" enctype="multipart/form-data" name="adminForm" id="call-form" class="form-validate form-horizontal">

	
	<?php echo HTMLHelper::_('uitab.startTabSet', 'myTab', array('active' => 'call')); ?>
	<?php echo HTMLHelper::_('uitab.addTab', 'myTab', 'call', Text::_('COM_BACKCALL_MAX_BOT', true)); ?>
	<div class="row-fluid">
		<div class="span10 form-horizontal">
			<fieldset class="adminform">
				<?php echo $this->form->renderField('title'); ?>
                <?php if ($this->active == 2) { ?>
                    <?php if ($this->item->active) { ?>
				        <?php echo $this->form->renderField('state'); ?>
                    <?php } else { ?>
                        <input type="hidden" name="jform[state]" value="<?php echo $this->item->state; ?>" />
                    <?php } ?>
                <?php } ?>

                <?php if (!$this->active) { ?>
                    <?php echo $this->form->renderField('token'); ?>
                <?php } else { ?>
                    <input type="hidden" name="jform[token]" value="<?php echo $this->item->token; ?>" />
                    <div id="botInfoBlock">
                        <?php if ($this->active == 1) { ?>
                            <div class="notifText"><?php echo Text::_('COM_BACKCALL_NOTIF_TEXT') ?></div>
                            <div id="codeBlock"><?php echo $this->item->code ?></div>
                            <script>
                                var intervalId;
                                var maxController = "<?php echo Uri::root() ?>index.php?option=com_backcall&task=maxbot.checkactive&id=<?php echo $this->item->id ?>"

                                document.addEventListener("DOMContentLoaded", () => {
                                    startPolling();
                                });

                                function startPolling() {
                                    intervalId = setInterval(() => {
                                        fetchDataFromServer();
                                    }, 1000); // интервал запросов — одна секунда
                                }

                                async function fetchDataFromServer() {
                                    try {
                                        const response = await fetch(maxController);

                                        const data = await response.json();

                                        if (data.success === true) {
                                            clearInterval(intervalId);
                                            location.reload();
                                        }
                                    } catch(error) {
                                        console.error("Error fetching data:", error.message);
                                    }
                                }
                            </script>
                        <?php } ?>
                        <?php if ($this->active == 2) { ?>
                            <h2 class="successh2"><?php echo Text::_('COM_BACKCALL_SUCCESS_MESSAGE') ?></h2>
                            <div class="oneBotInfo">
                                <div class="botLabel tokenLabel"><?php echo Text::_('COM_BACKCALL_YOUR_TOKEN') ?></div>
                                <div class="botValue tokenValue"><?php echo $this->item->token ?></div>
                            </div>
                            <div class="oneBotInfo">
                                <div class="botLabel tokenLabel"><?php echo Text::_('COM_BACKCALL_YOUR_CHAT_ID') ?></div>
                                <div class="botValue tokenValue"><?php echo $this->item->chat_id ?></div>
                            </div>
                            <div class="oneBotInfo">
                                <div class="botLabel tokenLabel"><?php echo Text::_('COM_BACKCALL_YOUR_USER_ID') ?></div>
                                <div class="botValue tokenValue"><?php echo $this->item->max_user_id ?></div>
                            </div>
                        <?php } ?>
                    </div>
                <?php } ?>
				<?php echo $this->form->renderField('created'); ?>
			</fieldset>
		</div>
	</div>
	<?php echo HTMLHelper::_('uitab.endTab'); ?>
    <?php echo $this->form->renderField('active'); ?>
    <?php echo $this->form->renderField('secret_word'); ?>
    <?php echo $this->form->renderField('code'); ?>
    <?php echo $this->form->renderField('max_user_id'); ?>
	<input type="hidden" name="jform[id]" value="<?php echo $this->item->id; ?>" />
	<input type="hidden" name="jform[ordering]" value="<?php echo $this->item->ordering; ?>" />
	<input type="hidden" name="jform[checked_out]" value="<?php echo $this->item->checked_out; ?>" />
	<input type="hidden" name="jform[checked_out_time]" value="<?php echo $this->item->checked_out_time; ?>" />
	<?php echo $this->form->renderField('created_by'); ?>
	<?php echo $this->form->renderField('modified_by'); ?>

	
	<?php echo HTMLHelper::_('uitab.endTabSet'); ?>

	<input type="hidden" name="task" value=""/>
	<?php echo HTMLHelper::_('form.token'); ?>

</form>
