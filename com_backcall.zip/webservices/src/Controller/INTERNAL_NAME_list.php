<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Backcall
 * @author     Владимир <mail@sitogon.ru>
 * @copyright  2022 Владимир
 * @license    GNU General Public License версии 2 или более поздней; Смотрите LICENSE.txt
 */
namespace Backcall\Component\Backcall\Api\Controller;

\defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\ApiController;

/**
 * The XXX_UCFIRST_INTERNAL_NAME_FORCE_LIST_XXX controller
 *
 * @since  1.0.0
 */
class XXX_UCFIRST_INTERNAL_NAME_FORCE_LIST_XXXController extends ApiController 
{
	/**
	 * The content type of the item.
	 *
	 * @var    string
	 * @since  1.0.0
	 */
	protected $contentType = 'XXX_INTERNAL_NAME_FORCE_LIST_XXX';

	/**
	 * The default view for the display method.
	 *
	 * @var    string
	 * @since  1.0.0
	 */
	protected $default_view = 'XXX_INTERNAL_NAME_FORCE_LIST_XXX';
}