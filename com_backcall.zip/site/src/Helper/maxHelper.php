<?php

namespace Backcall\Component\Backcall\Site\Helper;

// phpcs:disable PSR1.Files.SideEffects
defined('_JEXEC') or die;
// phpcs:enable PSR1.Files.SideEffects

use CURLFile;
use \Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;

class maxHelper {

    public $mainHelper;
    public function __construct() {
        $this->mainHelper = new MainHelper();
    }

    public function sendMessagesFromController($object, $module_params, $urltext_telegram, $subject, $files) {
        $maxbots = $module_params->get('maxbots', array());

        if (!is_array($maxbots)) {
            return false;
        }

        if (!count($maxbots)) {
            return false;
        }

        $maxbots = $this->getMaxBotsByIds($maxbots);

        if (!count($maxbots)) {
            return false;
        }

        $message = $this->getMaxBody($object, $module_params, $urltext_telegram, $subject);
        $fileTokens = array();

        if (!is_array($files)) {
            $files = array();
        }

        if (count($files)) {
            $firstMaxBot = $maxbots[0];
            $downLoadLink = $this->getDownloadMaxLink($firstMaxBot);

            foreach ($files as $file) {
                $token = $this->uploadFieToMax($downLoadLink, $file['full'], $firstMaxBot);

                if ($token) {
                    if (isset($token->fileId)) {
                        $fileTokens[] = $token;
                    }
                }
            }

            sleep(5);
        }



        foreach ($maxbots as $maxbot) {
            $filetoken= null;

            if (count($fileTokens)) {
                $filetoken = $fileTokens[0];
                unset($fileTokens[0]);
            }

            $this->sendSimpleMessage($message, $maxbot, $filetoken);

        }
    }

    public function uploadFieToMax($uploadUrl, $filePath, $localBot) {

        $accessToken = $localBot->token;

        $ch = curl_init();

        curl_setopt_array($ch, [
            CURLOPT_URL => $uploadUrl,
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => [
                'Authorization: ' . $accessToken
            ],
            CURLOPT_POSTFIELDS => [
                'data' => new CURLFile(realpath($filePath))
            ],
            CURLOPT_RETURNTRANSFER => true
        ]);

        $response = curl_exec($ch);

        if ($response === false) {
            return null;
        }

        curl_close($ch);

        if (!$this->mainHelper->isJson($response)) {
            return null;
        }

        $response = (object)json_decode($response);

        return $response;
    }

    public function getDownloadMaxLink($localBot) {

        $accessToken = $localBot->token;

        $url = 'https://platform-api.max.ru/uploads?type=file';
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Authorization: ' . $accessToken
        ));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($ch);

        if ($response === false) {
            return '';
        }

        curl_close($ch);

        if (!$this->mainHelper->isJson($response)) {
            return '';
        }

        $response = (object)json_decode($response);

        if (isset($response->url)) {
            return $response->url;
        }

        return '';
    }

    public function getMaxBotsByIds($maxbots) {

        if (!is_array($maxbots)) {
            return array();
        }

        if (!count($maxbots)) {
            return array();
        }

        $sqlIds = implode(',', $maxbots);

        $db = Factory::getContainer()->get('DatabaseDriver');
        $query = $db
            ->getQuery(true)
            ->select('*')
            ->from($db->quoteName('#__backcall_maxbots'))
            ->where($db->quoteName('state') ." = 1")
            ->where($db->quoteName('active') ." = 2")
            ->where($db->quoteName('id') . " IN (" . $sqlIds.")");

        $db->setQuery($query);
        $result = $db->loadObjectList();

        return $result;
    }

    public  function getMaxBody($object,  $module_params, $urltext, $subject) {

        $message = $module_params->get('messagetext','');
        $fullmess = '';

        $object->phone = '+'.preg_replace("/[^,.0-9]/", '',$object->phone);

        if ($subject) {
            $subject = '<strong>'.$subject.'</strong>'.chr(10).chr(10);
        } else {
            $subject = '';
        }

        if ($message) {
            $message = $message.chr(10) .chr(10) ;
        }

        if ($object->email) {
            $fullmess .=  Text::_('COM_BACKCALL_CALLS_EMAIL').':<br> ' . $object->email . chr(10) .chr(10);
        }

        if ($object->body) {
            $fullmess .= Text::_('COM_BACKCALL_ENTER_BODY').':<br>' . chr(10) .chr(10). $object->body. chr(10) .chr(10);
        }

        $body = $subject.$message .
            Text::_('COM_BACKCALL_NAME') .
            $object->client_name.chr(10) .
            Text::_('COM_BACKCALL_PHONE') . $object->phone . chr(10) .

            $fullmess.

            $urltext;

        return $body;

    }

    public function getMaxBotById($id) {
        $db = Factory::getContainer()->get('DatabaseDriver');
        $query = $db
            ->getQuery(true)
            ->select('*')
            ->from($db->quoteName('#__backcall_maxbots'))
            ->where($db->quoteName('id') . " = " . $id);

        $db->setQuery($query);
        $result = $db->loadObject();

        return $result;

    }

    public function getLocalBotByCode($code) {

        $code = trim($code);

        if (preg_match('/^\d+$/', $code)) {

            $db = Factory::getContainer()->get('DatabaseDriver');
            $query = $db
                ->getQuery(true)
                ->select('*')
                ->from($db->quoteName('#__backcall_maxbots'))
                ->where($db->quoteName('code') . " = " . $db->quote($code));

            $db->setQuery($query);
            $result = $db->loadObject();

            return $result;

        } else {
            return null;
        }
    }

    public function sendSimpleMessage($text, $localBot,  $fileToken = null) {

        $userId = $localBot->max_user_id;
        $chat_id = $localBot->chat_id;
        $accessToken = $localBot->token;

        $url = 'https://platform-api.max.ru/messages?user_id=' . $userId.'&chat_id='.$chat_id;

        $toSend = array();
        $toSend['text'] = $text;
        $toSend['format'] = 'html';

        if ($fileToken) {
            $toSend['attachments'] = array();

            $ob = new \stdClass();
            $ob->type = 'file';
            $ob->payload = $fileToken;
            $toSend['attachments'][] = $ob;
        }

        $data = json_encode($toSend);

        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: ' . $accessToken,
            'Content-Type: application/json'
        ]);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);


        $response = curl_exec($ch);

        if ($response === false) {
            return false;
        }

        curl_close($ch);

        return true;
    }
    public function getBotInfo($accessToken) {

        $ch = curl_init('https://platform-api.max.ru/me');
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: ' . $accessToken
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($ch);

        if ($response === false) {
            return null;
        }

        curl_close($ch);

        if ($this->mainHelper->isJson($response)) {
            $response = (object)json_decode($response);

            if (isset($response->message)) {
                if ($response->message == 'Invalid access_token') {
                    return null;
                }
            }

            return $response;
        }

        return null;

    }


    public function subscribe($accessToken, $secret_word) {

        $urlWebhook = $this->getSubscribeUrl();

        $data = json_encode([
            'url' => $urlWebhook,
            'update_types' => ['message_created', 'bot_started'],
            'secret' => $secret_word
        ]);


        $ch = curl_init('https://platform-api.max.ru/subscriptions');
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: ' . $accessToken,
            'Content-Type: application/json'
        ]);

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($ch);

        if ($response === false) {
            return false;
        }

        curl_close($ch);

        if (!$this->mainHelper->isJson($response)) {
            return false;
        }

        $response = (object)json_decode($response);

        if (!isset($response->success)) {
            return false;
        }

        if ((int)$response->success == 1) {
            return true;
        }

        return false;
    }

    public function unsubscribe($accessToken) {

        $webhookUrl = $this->getSubscribeUrl();

        $url = 'https://platform-api.max.ru/subscriptions?url=' . urlencode($webhookUrl);

        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: ' . $accessToken
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);


        $response = curl_exec($ch);

        if ($response === false) {
            die('cURL Error: ' . curl_error($ch));
        }

        curl_close($ch);

        echo $response;
    }

    public function getSubscribeUrl() {
        $uri = Uri::getInstance();
        $host = $uri->toString(array('host'));

        $url = 'https://{HOST}/index.php?option=com_backcall&task=maxbot.recieve';

        $url = str_replace('{HOST}', $host, $url);

        return $url;
    }

    public function randomNumberWithLength(int $length = 6): int {
        if ($length <= 0) {
            return 0;
        }

        $minValue = pow(10, $length - 1);
        $maxValue = pow(10, $length) - 1;

        return mt_rand($minValue, $maxValue);
    }
}