<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Backcall
 * @author     Владимир <mail@sitogon.ru>
 * @copyright  2022 Владимир
 * @license    GNU General Public License версии 2 или более поздней; Смотрите LICENSE.txt
 */

namespace Backcall\Component\Backcall\Site\Controller;

// phpcs:disable PSR1.Files.SideEffects
defined('_JEXEC') or die;
// phpcs:enable PSR1.Files.SideEffects

use Backcall\Component\Backcall\Site\Helper\MainHelper;
use Backcall\Component\Backcall\Site\Helper\maxHelper;
use Joomla\CMS\Application\CMSApplicationInterface;
use \Joomla\CMS\Application\SiteApplication;
use Joomla\CMS\Component\ComponentHelper;
use \Joomla\CMS\Factory;

use Joomla\CMS\Filesystem\Folder;
use \Joomla\CMS\Language\Multilanguage;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use \Joomla\CMS\Router\Route;
use \Joomla\CMS\Uri\Uri;
use Joomla\Input\Input;
use Joomla\Registry\Registry;
use \Joomla\Utilities\ArrayHelper;
use stdClass;


/**
 * Call class.
 *
 * @since  1.6.0
 */
class MaxbotController extends BaseController
{
    public $componentParams;
    public $maxHelper;
    public function __construct($config = [], MVCFactoryInterface $factory = null, ?CMSApplicationInterface $app = null, ?Input $input = null)
    {
        $this->componentParams =ComponentHelper::getParams('com_backcall');
        $this->maxHelper = new maxHelper();
        parent::__construct($config, $factory, $app, $input);
    }

    public function recieve() {

        $input = (object)json_decode(file_get_contents("php://input"));

        $data = new stdClass();
        $data->chat_id    = $input->message->recipient->chat_id;
        $data->max_user_id    = $input->message->recipient->user_id;
        $code = $input->message->body->text;

        $localBot = $this->maxHelper->getLocalBotByCode($code);

        if ($localBot) {
            $localBot->chat_id = $data->chat_id;
            $localBot->max_user_id = $data->max_user_id;
            $localBot->active = 2;
            $localBot->state = 1;
            $localBot->code = '';

            $db = Factory::getContainer()->get('DatabaseDriver');
            $db->updateObject('#__backcall_maxbots', $localBot, 'id', true);

            $this->maxHelper->sendSimpleMessage(Text::_('COM_BACKCALL_MAXBOT_THANKYOU'), $localBot);

            $this->maxHelper->unsubscribe($localBot->token);
        }


        die();
    }

    public function checkactive() {
        $app = Factory::getApplication();
        $input = $app->getInput();
        $message = new stdClass();
        $message->success = false;

        $id = $input->get('id', 0);

        if ($id) {
            $localBot = $this->maxHelper->getMaxBotById($id);

            if ($localBot->active == 2) {
                $message->success = true;
            }
        }

        echo json_encode($message);
        die();
    }

}
